#!/usr/bin/python
import os
from sys import argv
import  socket 
import sqlite3


file = "BlackList.ip"

def Append(ip):
	conn = sqlite3.connect("ips.db")
	c = conn.cursor()
	c.execute('INSERT INTO block_list  VALUES ("'+ip+'")')
	conn.commit()
	data = c.fetchall()

	return True

def Check(ip):
	conn = sqlite3.connect("ips.db")
	c = conn.cursor()
	c.execute('SELECT * from block_list WHERE ip =  "'+ip+'"')
	data = c.fetchall()
	if len(data) == 1:
		return True
	else:
		return False


def Remove(ip):
	conn = sqlite3.connect("ips.db")
	c = conn.cursor()
	c.execute('DELETE FROM block_list WHERE ip = ("'+ip+'")')
	conn.commit()
	return True

def print_all():
	conn = sqlite3.connect("ips.db")
	c = conn.cursor()
	c.execute('SELECT * from block_list ')
	data = c.fetchall()
	for ip in data:
		print ip
	return True

def Free_system():
	os.system("iptables -F")
	os.system("echo >  "+file+" ") 
	return True

def Block_ip(address):
	if Check(address):
		print "the %s alredy in Blocklist" % address
	else:
		os.system("iptables -A INPUT -s "+ address +"  -j DROP") 
		Append(address)
		print "SUCCESS"



def UnBlock_ip(address):

	if Check(address):
		os.system("iptables -D INPUT -s " + address + "  -j DROP")
		Remove(address)
		print "SUCCESS"
	else:
		print "the %s  in not in white list" % address

		#os.system("sed 's/%s/0/g' %s") % (address, file)

def list_allowing_ip():
	print_all()


def is_valid_ipv4_address(address):
    try:
        socket.inet_pton(socket.AF_INET, address)
    except AttributeError:  
        try:
            socket.inet_aton(address)
        except socket.error:
            return False
        return address.count('.') == 3
    except socket.error:  
        return False

    return True

def main():
	if (len(argv) == 1):
		print"|*****************************************************************************|"
		print"| use  xxx.xxx.xxx.xxx  enable            [to enable ip address]              |"
		print"| use  XXX.XXX.XXX.XXX  disable           [to remove ip from white list]       |"
		print"| use  list                               [to print list of white list ip]     |"
		print"| use  free                               [to free the system]                |"
		print"|                                                                             |"
		print"|*****************************************************************************|"
	elif(argv[1].upper() == "HELP"):
		print"|*****************************************************************************|"
		print"| use  xxx.xxx.xxx.xxx  enable            [to enable ip address]              |"
		print"| use  XXX.XXX.XXX.XXX  disable           [to remove ip from white list]       |"
		print"| use  list                               [to print list of white list ip]     |"
		print"| use  free                               [to free the system]                |"
		print"|                                                                             |"
		print"|*****************************************************************************|"

	elif(argv[1].upper()  == "LIST"):
		list_allowing_ip()
	elif(argv[1].upper() == "FREE"):
		Free_system()
		print "SUCCESS"
	elif(is_valid_ipv4_address(argv[1])):
		if(argv[2].upper() == "BLOCK"):
			Block_ip(argv[1])
		elif(argv[2].upper() == "UNBLOCK"):
			UnBlock_ip(argv[1])

		else:
			print "\n\t ERROR IN THE ACTION \n"
			print "\t use (enable)   to block ip address \n"
			print "\t use (disable) to unblock ip address\n"
			print "\t use (list)    to list all blocking ip "
	else:
		print "/n/t plise enter valied ip adress /n/n"

if __name__ == '__main__':
	main()

