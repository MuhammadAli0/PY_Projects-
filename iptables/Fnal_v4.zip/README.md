in the first you have to install  python-pip
second run this command           pip install -r requirements.txt
third  run                        iptables -A INPUT -p tcp --destination-port 5060 -j DROP

change the runing host and  port you will find it in the last line of 
demo.py ,,,  host="0.0.0.0", port=int(80)   change it to your machine ip ,  and change the port to what ever you need

after  it  just  run the server  with   python demo.py -m & 

