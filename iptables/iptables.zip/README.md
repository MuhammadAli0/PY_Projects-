# IpTables_5060

run this line before start 
sudo iptables -A INPUT -p tcp --destination-port 5060 -j DROP
